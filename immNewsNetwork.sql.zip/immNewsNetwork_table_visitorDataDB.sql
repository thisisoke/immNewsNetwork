
-- --------------------------------------------------------

--
-- Table structure for table `visitorDataDB`
--

CREATE TABLE `visitorDataDB` (
  `monthId` int(11) NOT NULL,
  `monthName` varchar(80) NOT NULL COMMENT 'Month Name',
  `visitorNumber` int(11) NOT NULL COMMENT 'visitor count'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `visitorDataDB`
--

INSERT INTO `visitorDataDB` (`monthId`, `monthName`, `visitorNumber`) VALUES
(1, 'January', 200),
(2, 'February', 40),
(3, 'March', 40987),
(4, 'April', 64738),
(5, 'May', 10),
(6, 'June', 100);
