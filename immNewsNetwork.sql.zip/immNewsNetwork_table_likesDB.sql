
-- --------------------------------------------------------

--
-- Table structure for table `likesDB`
--

CREATE TABLE `likesDB` (
  `id` int(11) NOT NULL,
  `articleId` int(11) NOT NULL COMMENT 'track which article is being liked',
  `username` varchar(200) NOT NULL COMMENT 'Track what user liked the article'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `likesDB`
--

INSERT INTO `likesDB` (`id`, `articleId`, `username`) VALUES
(2, 2, 'toro'),
(4, 1, 'toro'),
(9, 28, 'jshiu'),
(12, 1, 'jshiu'),
(13, 29, 'jshiu'),
(14, 27, 'toro'),
(15, 33, 'thisisoke'),
(16, 2, 'thisisoke'),
(17, 32, 'thisisoke'),
(18, 2, 'adurasa'),
(19, 1, 'adurasa'),
(20, 30, 'adurasa'),
(21, 32, 'adurasa'),
(22, 28, 'adurasa'),
(23, 2, 'dele'),
(24, 32, 'dele');
