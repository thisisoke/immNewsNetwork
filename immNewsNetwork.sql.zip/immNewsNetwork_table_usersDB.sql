
-- --------------------------------------------------------

--
-- Table structure for table `usersDB`
--

CREATE TABLE `usersDB` (
  `userId` int(11) NOT NULL,
  `username` varchar(80) NOT NULL,
  `password` varchar(200) NOT NULL,
  `userType` enum('admin','registered') NOT NULL,
  `email` varchar(80) NOT NULL COMMENT 'user email'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usersDB`
--

INSERT INTO `usersDB` (`userId`, `username`, `password`, `userType`, `email`) VALUES
(1, 'jshiu', 'coopersMom345', 'admin', ''),
(2, 'toro', 'ronto416', 'registered', ''),
(3, 'thisisoke', 'testAccount', 'registered', 'test@email.com'),
(4, 'adurasa', 'iloveseyitan', 'registered', 'adura@email.com'),
(5, 'dele', 'dele1234', 'registered', 'dele@email.com'),
(6, 'thisisoke2', 'testAccount', 'registered', 'g@email.com'),
(7, 'thisisoke4', 'testAccount', 'registered', 'd@email.com');
