
--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutPageDB`
--
ALTER TABLE `aboutPageDB`
  ADD PRIMARY KEY (`aboutPageId`);

--
-- Indexes for table `articleDB`
--
ALTER TABLE `articleDB`
  ADD PRIMARY KEY (`articleId`);

--
-- Indexes for table `contactDB`
--
ALTER TABLE `contactDB`
  ADD PRIMARY KEY (`contactId`);

--
-- Indexes for table `likesDB`
--
ALTER TABLE `likesDB`
  ADD PRIMARY KEY (`id`),
  ADD KEY `articleId` (`articleId`);

--
-- Indexes for table `usersDB`
--
ALTER TABLE `usersDB`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `visitorDataDB`
--
ALTER TABLE `visitorDataDB`
  ADD PRIMARY KEY (`monthId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutPageDB`
--
ALTER TABLE `aboutPageDB`
  MODIFY `aboutPageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `articleDB`
--
ALTER TABLE `articleDB`
  MODIFY `articleId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the Article ID to be used in relation ', AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `contactDB`
--
ALTER TABLE `contactDB`
  MODIFY `contactId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `likesDB`
--
ALTER TABLE `likesDB`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `usersDB`
--
ALTER TABLE `usersDB`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `visitorDataDB`
--
ALTER TABLE `visitorDataDB`
  MODIFY `monthId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
