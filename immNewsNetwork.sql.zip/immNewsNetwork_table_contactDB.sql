
-- --------------------------------------------------------

--
-- Table structure for table `contactDB`
--

CREATE TABLE `contactDB` (
  `contactId` int(11) NOT NULL,
  `firstname` varchar(80) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Public contact first name',
  `lastname` varchar(80) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Public contact Last name',
  `email` varchar(80) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Email',
  `categoryIndustry` tinyint(1) NOT NULL COMMENT 'Category interest 1',
  `categoryTechnical` tinyint(1) NOT NULL COMMENT 'Category interest 2',
  `categoryCareer` tinyint(1) NOT NULL COMMENT 'Category interest 3',
  `role` enum('writer','contributor','administrator') NOT NULL COMMENT 'role in contact form'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contactDB`
--

INSERT INTO `contactDB` (`contactId`, `firstname`, `lastname`, `email`, `categoryIndustry`, `categoryTechnical`, `categoryCareer`, `role`) VALUES
(1, 'firstname', 'lastname', 'email', 1, 1, 1, 'writer'),
(2, 'test2', 'lastname', 'email', 1, 1, 1, 'writer'),
(3, 'test23', 'name', 'test@email.com', 1, 1, 1, 'writer'),
(4, 'this is ', 'a test', 'ateas@email.com', 1, 1, 1, 'writer'),
(5, 'thisanothertest', 'here', 'goes@gmail.com', 0, 1, 1, 'writer'),
(6, 'd', 'd', 'd@emai.com', 0, 0, 0, 'writer'),
(7, '32', '2', 'd@gmail.com', 0, 0, 0, 'contributor'),
(8, '32', '2', 'd@gmail.com', 0, 0, 0, 'contributor'),
(9, 'Ken', 'Gabe', 'gk@emailcom', 1, 0, 0, 'contributor');
