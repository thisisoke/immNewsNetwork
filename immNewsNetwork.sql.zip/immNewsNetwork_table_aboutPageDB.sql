
-- --------------------------------------------------------

--
-- Table structure for table `aboutPageDB`
--

CREATE TABLE `aboutPageDB` (
  `aboutPageId` int(11) NOT NULL,
  `aboutPageTitle` varchar(100) NOT NULL,
  `aboutPageDescription` varchar(400) NOT NULL COMMENT 'About Page Description'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aboutPageDB`
--

INSERT INTO `aboutPageDB` (`aboutPageId`, `aboutPageTitle`, `aboutPageDescription`) VALUES
(1, 'About Page ', 'The IMM News site is about quality news media coverage. A bit more about the site. We have all kinds of content on this site  ');
